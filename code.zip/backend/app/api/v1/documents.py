
import hashlib
from pathlib import Path
from uuid import UUID
import logging

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
    status,
)
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.dependencies.auth import get_current_user

from app.models.document import (
    Document,
    DocumentVersion,
    DocumentChunk,
    DocumentStatus,
)
from app.models.user import Department, User, UserDepartment

from app.modules.ingestion.validators import validate_upload

from app.modules.ingestion.parsers.pdf_parser import (
    parse_pdf,
    PDFParserError,
)
from app.modules.ingestion.parsers.docx_parser import (
    parse_docx,
    DOCXParserError,
)
from app.modules.ingestion.parsers.html_parser import (
    parse_html,
    HTMLParserError,
)

from app.modules.ingestion.processing.ingestion_service import (
    process_parsed_document,
)
from app.modules.ingestion.processing.file_storage import (
    store_file,
    delete_file,
    FileStorageError,
)


router = APIRouter(prefix="/documents", tags=["Documents"])
logger = logging.getLogger(__name__)


class DocumentUploadResponse(BaseModel):
    document_id: UUID
    document_name: str
    file_type: str
    status: str
    file_size: int
    total_chunks: int
    total_tokens: int
    department_id: UUID
    version_number: int
    metadata: dict


def authorize_department(
    db: Session,
    user: User,
    department_id: UUID,
) -> None:
    department = db.scalar(
        select(Department).where(
            Department.id == department_id,
            Department.is_active.is_(True),
        )
    )

    if department is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Department not found.",
        )

    role = getattr(user.role, "value", user.role)

    if role == "ADMIN":
        return

    membership = db.scalar(
        select(UserDepartment.id).where(
            UserDepartment.user_id == user.id,
            UserDepartment.department_id == department_id,
        )
    )

    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to upload to this department.",
        )


@router.post(
    "/upload",
    response_model=DocumentUploadResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload_document(
    file: UploadFile = File(...),
    department_id: UUID = Form(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # 1. Check department authorization before processing file content.
    authorize_department(db, current_user, department_id)

    # 2. Validate uploaded file.
    validated = await validate_upload(file)

    # 3. Parse the document.
    try:
        if validated.extension == ".pdf":
            parsed_document = parse_pdf(
                validated.content,
                validated.filename,
            )

        elif validated.extension == ".docx":
            parsed_document = parse_docx(
                validated.content,
                validated.filename,
            )

        elif validated.extension in {".html", ".htm"}:
            parsed_document = parse_html(
                validated.content,
                validated.filename,
            )

        else:
            raise HTTPException(
                status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                detail="Unsupported document format.",
            )

        # 4. Normalize and generate chunks.
        result = process_parsed_document(parsed_document)

    except (PDFParserError, DOCXParserError, HTMLParserError) as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Document parsing failed: {exc}",
        ) from exc

    except TypeError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Document processing failed.",
        ) from exc

    # 5. Store original file.
    storage_path = None

    try:
        storage_path = store_file(
            content=validated.content,
            extension=validated.extension,
            storage_root=settings.DOCUMENT_STORAGE_ROOT,
        )

        # 6. Calculate original file checksum.
        checksum = hashlib.sha256(validated.content).hexdigest()

        # 7. Create document record.
        document_title = (
            result.metadata.get("title")
            or Path(validated.filename).stem
        )

        document = Document(
            title=str(document_title)[:255],
            original_filename=validated.filename[:255],
            file_type=result.file_type,
            department_id=department_id,
            uploaded_by=current_user.id,
            status=DocumentStatus.COMPLETED,
        )

        db.add(document)
        db.flush()

        # 8. Create document version.
        version = DocumentVersion(
            document_id=document.id,
            version_number=1,
            checksum=checksum,
            storage_path=storage_path,
            file_size=validated.size,
        )

        db.add(version)
        db.flush()

        # 9. Persist chunks.
        for chunk in result.chunks:
            db.add(
                DocumentChunk(
                    document_id=document.id,
                    version_id=version.id,
                    chunk_index=chunk.chunk_index,
                    content=chunk.content,
                    page_number=chunk.page_number,
                    section_title=chunk.section_title,
                    token_count=chunk.token_count,
                    metadata_json={
                        "source_block_start": chunk.source_block_start,
                        "source_block_end": chunk.source_block_end,
                    },
                )
            )

        # 10. Commit all database records atomically.
        db.commit()
        db.refresh(document)

        return DocumentUploadResponse(
            document_id=document.id,
            document_name=document.original_filename,
            file_type=document.file_type,
            status=document.status.value,
            file_size=validated.size,
            total_chunks=result.total_chunks,
            total_tokens=result.total_tokens,
            department_id=document.department_id,
            version_number=version.version_number,
            metadata=result.metadata,
        )

    except FileStorageError as exc:
        db.rollback()

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Unable to store uploaded document.",
        ) from exc

    except Exception as exc:
        db.rollback()

        logger.exception(
            "Document persistence failed for file: %s",
            validated.filename,
        )

        if storage_path:
            try:
                delete_file(
                    storage_path,
                    settings.DOCUMENT_STORAGE_ROOT,
                )
            except FileStorageError:
                logger.exception(
                    "Failed to clean up stored file: %s",
                    storage_path,
                )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Document persistence failed. Check backend logs.",
        ) from exc