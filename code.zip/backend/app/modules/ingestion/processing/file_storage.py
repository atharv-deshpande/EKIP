
from pathlib import Path
from uuid import uuid4
import os
import tempfile


class FileStorageError(Exception):
    """Raised when a document cannot be stored or removed."""


def store_file(
    content: bytes,
    extension: str,
    storage_root: Path,
) -> str:
    """
    Store a document using a generated UUID path.

    Returns a relative POSIX path suitable for PostgreSQL.
    """
    if not content:
        raise FileStorageError("Cannot store an empty file.")

    extension = extension.lower()

    if not extension.startswith(".") or len(extension) > 10:
        raise FileStorageError("Invalid file extension.")

    storage_root = storage_root.resolve()
    document_dir = storage_root / str(uuid4())
    document_dir.mkdir(parents=True, exist_ok=False)

    destination = document_dir / f"{uuid4()}{extension}"
    temporary_path = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=document_dir,
            prefix=".upload-",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)
            temporary_file.write(content)
            temporary_file.flush()
            os.fsync(temporary_file.fileno())

        os.replace(temporary_path, destination)

        return destination.relative_to(storage_root).as_posix()

    except OSError as exc:
        if temporary_path and temporary_path.exists():
            temporary_path.unlink(missing_ok=True)

        raise FileStorageError("Unable to store uploaded document.") from exc


def delete_file(relative_path: str, storage_root: Path) -> None:
    """Delete a stored document without allowing paths outside storage_root."""
    root = storage_root.resolve()
    target = (root / relative_path).resolve()

    if not target.is_relative_to(root):
        raise FileStorageError("Invalid storage path.")

    try:
        if target.is_file():
            target.unlink()

        if target.parent != root and target.parent.exists():
            target.parent.rmdir()

    except OSError as exc:
        raise FileStorageError("Unable to remove stored document.") from exc
